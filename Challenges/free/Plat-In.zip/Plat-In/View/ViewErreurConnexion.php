<html>
    <head>
        <title>Plat'In</title>
    </head>
    
    <body>
        <?php     
        require("View/ViewBanner.php"); 
        ?>
        <div class="text-center mt-5">


        Veuillez vous <a href="Index.php?page=Inscription"> inscrire</a> ou vous <a href="Index.php?page=Connexion"> connectez</a> pour accéder a cette page
        </div>
    </body>
</html>