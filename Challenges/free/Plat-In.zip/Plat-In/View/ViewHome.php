<html>
    <head>
        <title>Plat'In</title>
    </head>
    
    <body>
        <?php
        
        require("View/ViewBanner.php");     
        
        ?>
    </body>
</html>