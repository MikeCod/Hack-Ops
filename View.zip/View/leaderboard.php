<h1>Leaderboard</h1>
<br>
<br>
<table width="800px">
    <tr style="font-weight:bold;">
        <td>Rank</td>
        <td>User</td>
        <td>Score</td>
    </tr>
    <?php
    require_once "../model/leaderboard.php";
    include "../controller/leaderboard.php";
    ?>
</table>