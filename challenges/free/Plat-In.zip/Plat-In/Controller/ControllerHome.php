<?php

    require('ControllerStaple.php');
    CheckSesion();
    CheckLogOut();
    require("View/ViewHome.php");

?>