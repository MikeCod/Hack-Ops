<?php

    $Bdd = new PDO("mysql:host=localhost;dbname=Plat_In","root","");
    
?>