<?php

define('NAME', 'Hack Ops');

# Database management system to use
define('DBMS', 'MySQL');

define('HOST', 'localhost');
define('DB_NAME', "HackOps");
define('USER', 'root');
define('PASS', '');

# Tables
define('USERS', 'users'); # Users

#Badges
define('B_SCORE', 'Score');
define('B_CHALL', 'Challenge');
define('B_RANK', 'Rank');

/* -- */


?>